
print("bar")
raise ValueError("foo")