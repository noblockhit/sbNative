# SbNative
An extention to python for debugging and such. Things that, well `Should Be Native`


## SbNative may be used for
  - private projects.
  - public projects (The SbNative repo must be referenced in a Readme in case the source code is available.)

DO NOT DISTRIBUTE.

ALL NON MENTIONED RIGHTS RESERVED.
